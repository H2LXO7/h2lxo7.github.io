<?php include 'header.php'; ?>

			<div role="main" class="main">
				<div class="container">
					<div class="row pt-xl">

						<div class="col-md-9">

							<h1 class="mt-xl mb-none">Law Firm Attorneys</h1>
							<div class="divider divider-primary divider-small mb-xl">
								<hr>
							</div>

							<div class="row">

								<div class="col-md-12">

									<h1>HABER DETAY SAYFASI</h1>

									<P>Haber detayları burada yer alacak</P>
								</div>

							</div>

						</div>


						<!-- Slidebar -->

						<?php include 'rightbar.php'; ?>
					</div>

				</div>
			</div>

<?php include 'footer.php'; ?>